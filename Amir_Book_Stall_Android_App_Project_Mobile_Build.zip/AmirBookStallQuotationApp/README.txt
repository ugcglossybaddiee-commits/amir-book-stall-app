AMIR BOOK STALL SALES QUOTATION APP — ANDROID STUDIO PROJECT

This is an Android Studio project wrapper for the existing quotation software.
It includes the HTML software locally, so the quotation editor can run offline.
The Print / Save PDF button opens Android's native print dialog (Save as PDF or select a printer).
Saved quotations/settings use the WebView browser storage on that device.

IMPORTANT: This ZIP is the app source project, not a compiled APK. The current environment does not have the Android SDK/build tools needed to compile and sign an APK.

HOW TO BUILD THE APK:
1. On a Windows/Mac/Linux computer, install Android Studio.
2. Extract this ZIP.
3. In Android Studio choose Open and select the extracted AmirBookStallQuotationApp folder.
4. Allow Gradle sync and install the Android SDK requested by Android Studio.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the APK location (usually app/build/outputs/apk/debug/app-debug.apk).
7. Transfer that APK to your Android phone and install it. You may need to allow installation from that source.

The app package ID is com.amirbookstall.quotation.
