AMIR BOOK STALL QUOTATION APP — ICON-READY BUILD

This project includes the blue book-and-pencil launcher icon in all mipmap sizes and AndroidManifest.xml points to it.

For the GitHub workflow already configured in your repository:
1. Upload this ZIP to the repository root, using the exact filename: Amir_Book_Stall_Android_App_Project_Mobile_Build.zip
2. Choose Commit changes.
3. Open Actions and open the newest “Build Amir Book Stall APK” run.
4. Wait for Success, then scroll to Artifacts and download “Amir-Book-Stall-APK”.
5. Extract the downloaded artifact ZIP and install app-debug.apk.

Install the new APK over the old app if Android permits. If the launcher still shows the old icon, uninstall the old app first and install the new APK. The app icon is included in the source; this ZIP is not itself an APK.
