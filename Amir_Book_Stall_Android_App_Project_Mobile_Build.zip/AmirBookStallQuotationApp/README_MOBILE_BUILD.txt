AMIR BOOK STALL - BUILD APK USING AN ANDROID PHONE

This project includes a GitHub Actions workflow that builds a test/debug APK in the cloud.

1. Download and extract this ZIP on your phone (Files app > Extract).
2. In Chrome, open https://github.com and sign in/create a free account.
3. Create a NEW repository, for example: amir-book-stall-app. Public or private is your choice.
4. Upload the CONTENTS of the extracted AmirBookStallQuotationApp folder to the repository root.
   IMPORTANT: upload the hidden .github folder too. If the phone file picker hides it, use GitHub's web editor to create .github/workflows/build-apk.yml and paste the workflow from this project.
5. Open the repository > Actions tab > select “Build Amir Book Stall APK”. If prompted, enable Actions.
6. Press “Run workflow” (or wait for the first push build) and wait until the run is green/successful.
7. Open that completed run, scroll to Artifacts, and download “Amir-Book-Stall-APK”.
8. Extract the downloaded artifact ZIP. Find app-debug.apk, tap it, and allow Chrome/Files to install unknown apps if Android asks.

This is a debug/test APK for personal use. It is not a Play Store release. Keep the repository private if you prefer not to share the app source publicly. Do not upload passwords or private signing keys.
